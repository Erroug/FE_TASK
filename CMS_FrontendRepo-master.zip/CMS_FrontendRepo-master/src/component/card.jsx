
import React from 'react';

const TopCard = ({ title }) => (
  <div >
    {title}
  </div>
);

export {TopCard};