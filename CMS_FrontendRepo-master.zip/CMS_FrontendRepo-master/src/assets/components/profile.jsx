const Profile = () => {
  return (
    <div className=" w-[60px] h-[60px] bg-white border-2 border-gray-300 rounded-full flex items-center justify-center">
      {/* Optional image inside */}
    </div>
  );
};

export default Profile;
// import React from "react";

// const profile = () => {
//     return (
// <div className="absolute top-7 right-10 h-[22px] w-[22px] p-7 bg-white border-2 border-gray-300 rounded-full"></div>

        
// );
// }   
//   export default profile;

